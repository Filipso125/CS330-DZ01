package rs.ac.metropolitan.data

import retrofit2.http.Body
import retrofit2.http.DELETE
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Path
import rs.ac.metropolitan.common.StudentItem

interface ApiService {
        @GET(Constants.STUDENT_URL)
        suspend fun getStudents(): List<StudentItem>

        @POST(Constants.STUDENT_URL)
        suspend fun addStudent(@Body studentItem: StudentItem)

        @DELETE(Constants.STUDENT_URL+"/{id}")
        suspend fun deleteStudent(@Path ("id") id: String)
}