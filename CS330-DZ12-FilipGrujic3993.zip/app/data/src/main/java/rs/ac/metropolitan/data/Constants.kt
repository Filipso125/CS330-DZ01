package rs.ac.metropolitan.data

class Constants {
    companion object {
        const val BASE_URL = "http://192.168.1.197:3001/"
        const val STUDENT_URL = "student"
    }
}