package rs.ac.metropolitan.repository

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.launch
import kotlinx.coroutines.newSingleThreadContext
import rs.ac.metropolitan.data.ApiService
import rs.ac.metropolitan.data.RetrofitHelper
import rs.ac.metropolitan.common.StudentItem

class Repository {
    var studentsFlow: Flow<List<StudentItem>> = flowOf( listOf())


    suspend fun loadStudents(){
        val apiService = RetrofitHelper.getInstance().create(ApiService::class.java)
        val result = apiService.getStudents()
        if (result != null)
        // Checking the results
            studentsFlow = flowOf(result)
    }

    suspend fun submitStudent(studentItem: StudentItem){
        val apiService = RetrofitHelper.getInstance().create(ApiService::class.java)
        val result = apiService.addStudent(studentItem)
    }

    suspend fun deleteStudent(id: String){
        val apiService = RetrofitHelper.getInstance().create(ApiService::class.java)
        val result = apiService.deleteStudent(id)
    }
}