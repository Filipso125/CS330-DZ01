package rs.ac.metropolitan.common


class Students : ArrayList<StudentItem>()