package rs.ac.metropolitan.common


import java.time.LocalDate
import java.util.Date

data class StudentItem(
    val id: String,
    val fname: String,
    val lname: String,
    val avatar: String,
    val email: String,
    val birthdate: Date,
    val sex: String,
    val studyYear: String,
    val startAt: Date
)