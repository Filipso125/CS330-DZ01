package rs.ac.metropolitan.student.view

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.livedata.observeAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import rs.ac.metropolitan.common.StudentItem
import rs.ac.metropolitan.student.AppViewModel
import rs.ac.metropolitan.student.ui.theme.StudentTheme

@Composable
fun StudentListPage(vm: AppViewModel, paddingValues: PaddingValues) {
    val students = vm.students.observeAsState()
    LaunchedEffect(vm.loadStudents()) {
    }

    LazyColumn(modifier = Modifier.padding(paddingValues)) {
        students.value?.let {
            items(it) { student ->
                StudentCardView(student) {
                    vm.navigateToUserDetails(it)
                }
            }
        }
    }
}

@Composable
fun StudentCardView(student: StudentItem, onSelected: (String) -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(8.dp)
            .clickable { onSelected(student.id) }
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(8.dp)
        ) {
            AsyncImage(
                model = student.avatar,
                contentDescription = null,
                modifier = Modifier
                    .size(60.dp)
                    .clip(CircleShape)
            )
            Column(
                modifier = Modifier
                    .padding(8.dp)
                    .width(250.dp),
                verticalArrangement = Arrangement.Center
            ) {
                Text(
                    text = "${student.fname} ${student.lname}",
                    fontSize = 18.sp
                )
                Text(
                    text = "Email: ${student.email}", color = Color.Gray,
                    modifier = Modifier.padding(4.dp)
                )
            }
            Spacer(modifier = Modifier.weight(1f))
            Row(verticalAlignment = Alignment.CenterVertically) {

                Box(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "${student.studyYear}", modifier = Modifier.padding(4.dp),
                        style = MaterialTheme.typography.titleMedium
                    )
                }
            }
        }
    }
}

@Preview
@Composable
fun ListStudentViewPreview() {
    StudentTheme {
        StudentListPage(AppViewModel(), PaddingValues())
    }
}